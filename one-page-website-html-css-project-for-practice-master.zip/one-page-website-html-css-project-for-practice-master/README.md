# one-page-website-html-css-project-for-practice
## Watch The Complete Tutorial : https://youtu.be/ZFQkb26UD1Y

This project is for html &amp; css practice. We made this for youtube tutorial purpose.
<b>coded by [Shaif Arfan](https://github.com/shaifarfan)</b>
### 👍 HAVE FUN 👍
Thanks, Arfan

![Watch Now](./img/Design.jpg)
